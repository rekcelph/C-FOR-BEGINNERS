#include <iostream>
using namespace std;

int main ()
{
    int number [5]={1, 0, 12, 4 , 12};
    
    for (int x = 0 ; x < 5 ; x ++)
    {
        cout << "Enter a number : "<< endl;
        cin >> number [x];

    }
     cout << " The outcome is "<< number << endl;
      
      return 0;

}
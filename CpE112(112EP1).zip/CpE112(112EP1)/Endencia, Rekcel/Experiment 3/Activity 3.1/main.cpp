#include <iostream>
#include <cmath>

using namespace std;

int main() {

    double side_a, side_b, side_c, angle_A, angle_B, angle_C;

    cout << "Enter the length of side a (adjacent): ";
    cin >> side_a;

    cout << "Enter the length of side b (opposite): ";
    cin >> side_b;

    side_c = sqrt(side_a * side_a + side_b * side_b);

    angle_A = asin(side_a / side_c) * 180 / 3.1415926535;
    angle_B = atan(side_b / side_a) * 180 / 3.1415926535;
    angle_C = 90;

    cout << "Result:" << endl;
    cout << "Side c (hypotenuse): " << side_c << endl;
    cout << "Angle A: " << angle_A << " degrees" << endl;
    cout << "Angle B: " << angle_B << " degrees" << endl;
    cout << "Angle C: " << angle_C << " degrees" << endl;

    return 0;
}

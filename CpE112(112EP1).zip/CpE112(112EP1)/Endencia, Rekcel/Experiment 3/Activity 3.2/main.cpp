#include <iostream>
#include <cmath>

using namespace std;

int main() {
    double radius, height;


    cout << "Enter the radius of the right cylinder: ";
    cin >> radius;

    cout << "Enter the height of the right cylinder: ";
    cin >> height;


    double pi = 3.14159265359;
    double volume = pi * radius * radius * height;
    double lateralArea = 2 * pi * radius * height;
    double baseArea = pi * radius * radius;
    double surfaceArea = lateralArea + (2 * baseArea);


    cout << "The Volume of the right cylinder is " << volume << " cubic units." << endl;
    cout << "The Lateral Area of the right cylinder is " << lateralArea << " square units." << endl;
    cout << "The Base Area of the right cylinder is " << baseArea << " square units." << endl;
    cout << "The Surface Area of the right cylinder is " << surfaceArea << " square units." << endl;

    return 0;
}

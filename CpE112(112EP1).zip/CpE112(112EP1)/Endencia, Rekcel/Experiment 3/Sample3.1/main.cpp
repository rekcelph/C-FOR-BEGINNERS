#include <iostream>

using namespace std;
#define PI 3.14159

int main()
{
    float radius, height;
    float Surface_Area, Volume;

    cout <<"CYLINDER VOLUME AND SURFACE AREA CALCULATOR" << endl;
    cout <<"\nEnter Radius: ";
    cin >> radius;
    cout <<"Enter Height: ";
    cin >> height;

    Surface_Area = 2*PI*radius*height+2*PI*radius*radius;
    Volume = PI * radius * radius * height;

    cout <<"Surface Area = " << Surface_Area << "square units" << endl;
    cout <<"Volume = " << Volume << "cubic units" << endl;

    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    int start_number;
    int end_number;

    cout << " Start to End \n" << endl;
    cout << " Enter the Starting number  : " ;
    cin >> start_number;
    cout << " Enter the Ending number  : " ;
    cin >> end_number;

    if (start_number <= end_number )
    {
        cout << "The starting number should be higher than the ending number" << endl;
        return 1;


    }
    int sum = 0;

    for (int x = end_number; x <= start_number; x++)
    {
        sum += x;

    }
    cout << "Sum of all the natural numbers from" << end_number << " to " << start_number << " : " << sum << endl;

}
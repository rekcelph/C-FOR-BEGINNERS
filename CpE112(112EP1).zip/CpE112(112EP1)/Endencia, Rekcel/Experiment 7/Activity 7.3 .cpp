#include <iostream>

using namespace std;

int main() {
    int even_count = 0;
    int odd_count = 0;
    int num[10];
    cout << "Even or Odd numbers" << endl;

    for (int x = 0; x < 10; x++) 
    { 
        cout << "Enter number " << x + 1 << ": ";
        cin >> num[x];
    }

    for (int x = 0; x < 10; x++) 
    { 
        if (num[x] % 2 == 0) {
            even_count++;
        } else {
            odd_count++;
        }
    }

    cout << "Even Numbers: " << even_count << endl;
    cout << "Odd Numbers: " << odd_count << endl;

    return 0;
}

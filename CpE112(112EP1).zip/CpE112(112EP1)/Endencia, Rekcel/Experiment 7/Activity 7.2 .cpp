#include <iostream>

using namespace std;

int main()
{
    int upper_limit;
    int sum = 0;

    cout << "Upper limits" << endl; 
    cout << "Enter an upper limit: ";
    cin >> upper_limit;

    for (int x = 1; x <= upper_limit; x++)
    {
        if (x % 3 == 0)
        {
            cout << x << " ";
            sum += x;
        }
    }
    
    cout << endl << "Sum of all the numbers divisible by 3: " << sum << endl;

    return 0;
}

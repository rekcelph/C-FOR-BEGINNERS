#include <iostream>

using namespace std;

int main()
{
    char choice ;
    float num1, num2;
    cout << "Simple calculator " << endl;
    cout << "What do you want me to do?? " ;
    cin >> choice;
    cout << " Enter 1st number " ;
    cin >> num1;
    cout << " Enter 2nd number " ;
    cin>> num2;

    if (choice == '+')
    {
        cout << " sum of "<< num1 << " and "<< num2 << " is " <<num1 + num2;
    }
    else if (choice == '-')
    {
        cout << " The difference of " << num1 << " and " << num2 << " is "<< num1 - num2;
    }
    else if  (choice == '*')
    {
        cout << " The product of " << num1 << " and " << num2 << " is " << num1 * num2;
    }
    else if  (choice == '/')
    {
        cout << " quotient of " << num1 << " and " << num2 << " is " << num1 / num2;
    }
    else
    {
        cout << " invalid shit! ";
    }
    return 0;
}

#include <iostream>
using namespace std;

int main ()
{
    int number [10];
    cout<<"Enter a odd numbers only " << endl;
    
    for (int x = 0 ; x < 10 ; x ++)
    
    {
        cout << "Enter a number : " ;
        cin >> number [x];
    
    if (number [x] % 2==0)
    {
        cout << "Not an ODD number, Read instructions.." << endl;
    }
    for (int y = 9 ; y >= 0 ; y--)
    {
        cout<< number [y]<< endl;
    }

    return 0;

    }
}

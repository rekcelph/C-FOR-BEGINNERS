#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    double item_1, item_2, item_3, item_4, item_5;

    cout << "Enter the amount for item 1: ";
    cin >> item_1;

    cout << "Enter the amount for item 2: ";
    cin >> item_2;

    cout << "Enter the amount for item 3: ";
    cin >> item_3;

    cout << "Enter the amount for item 4: ";
    cin >> item_4;

    cout << "Enter the amount for item 5: ";
    cin >> item_5;

    double totalAmount = item_1 + item_2 + item_3 + item_4 + item_5;
    double discount = 0;

    if (totalAmount >= 10000)
    {
        discount = totalAmount * 0.2;
        totalAmount *= 0.8;
    }
    else if (totalAmount >= 5000)
    {
        discount = totalAmount * 0.15;
        totalAmount *= 0.85;
    }
    else if (totalAmount >= 1000)
    {
        discount = totalAmount * 0.1;
        totalAmount *= 0.9;
    }

    cout << "Discount Applied: " << fixed << setprecision(2) << discount << " Pesos" << endl;

    cout << "Total Amount: " << fixed << setprecision(2) << totalAmount << " Pesos" << endl;

    return 0;
}

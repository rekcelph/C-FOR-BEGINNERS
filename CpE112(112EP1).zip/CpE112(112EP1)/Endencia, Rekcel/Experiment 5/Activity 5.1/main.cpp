#include <iostream>
using namespace std;

int main()
{
    int physics, chemistry, biology, mathematics, computer;

    cout << "Enter marks for Physics: ";
    cin >> physics;

    cout << "Enter marks for Chemistry: ";
    cin >> chemistry;

    cout << "Enter marks for Biology: ";
    cin >> biology;

    cout << "Enter marks for Mathematics: ";
    cin >> mathematics;

    cout << "Enter marks for Computer: ";
    cin >> computer;


    int totalMarks = physics + chemistry + biology + mathematics + computer;
    int percentage = (totalMarks / 5);


    char grade;

    if ( percentage >= 101)
        {
        cout << "This is not a valid grade " << endl;

        }
    else if ( percentage <=0)
        {
        cout <<"This is not a valid grade " << endl ;

        }
    else if (percentage >= 90)
        {
        grade = 'A';
        }
    else if (percentage >= 80)
        {
        grade = 'B';
        }
    else if (percentage >= 70)
        {
        grade = 'C';
        }
    else if (percentage >= 60)
        {
        grade = 'D';
        }
    else if (percentage >= 50)
        {
        grade = 'E';
        }
    else
        {
        grade = 'F';
        cout << "Congrats! you did not passed " << endl;

        }



    cout << "Percentage: " << percentage << "%" << endl;
    cout << grade << endl;

    return 0;
}

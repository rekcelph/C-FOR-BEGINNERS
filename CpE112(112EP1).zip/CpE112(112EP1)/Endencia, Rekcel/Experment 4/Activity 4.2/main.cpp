#include <iostream>

using namespace std;

int main()
{
    int number;

    cout << "Enter a positive number: " << endl;
    cin >> number;

    if (number <= 0)
    {

    cout << "Enter positive numbers only... " << endl;

    }
    else
    {
    if (number % 5 == 0)
    {

    cout << "Thank you" << endl;
    cout << "The number is divisible by 5." << endl;

    }
    else
    {

    cout << "Thank You!!" << endl;
    cout << "The number is not divisible by 5." << endl;

    }
    }

    return 0;
}

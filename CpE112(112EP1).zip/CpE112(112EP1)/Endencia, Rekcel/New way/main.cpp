#include <iostream>

using namespace std;

int main()
{


    int number;
    cout<< "The program will determine if the number is a prime or not"<<endl;

    cout << "Enter number:";

    cin >> number;

    if ((number ==2 )||(number ==3)|| (number == 7)|| (number == 5))
    {
    cout<< "The number is not a prime number";
    }
    else if((number% 2==0)|| (number% 3==0)||(number% 4==0)||(number% 5==0)||(number% 7==0) ||(number% 8==0)||(number% 9==0))
    {
    cout <<"The number is not a prime number" << endl;
    }
    else
    {
    cout<< "The number is a prime number" << endl;
    }
    return 0;
}

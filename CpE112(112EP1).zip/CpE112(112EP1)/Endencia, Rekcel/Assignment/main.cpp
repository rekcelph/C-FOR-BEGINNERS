#include<iostream>
using namespace std;

int main()
{

	int number;
    cout << "Enter a number:";
    cin >> number;
    if (number == 2)

    {
        cout << "The number is a prime" << endl;
    }


    else if (number%2 == 0)

    {
        cout << "The number is not a prime" << endl;
    }
    else if (number% 3 == 0)
    {
        cout << "The number is a prime number"<< endl;

    }
    else if (number %4 == 0)
    {
        cout << "The number is a prime number" << endl;
    }
    else if (number%5 ==0)
    {
        cout << "The number is a prime number"<< endl;
    }
    else if (number% 6 ==0)
    {
        cout <<"The number is not a prime number"<< endl;
    }
    else if (number% 7 ==0)
    {
        cout <<"The number is not a prime numbber" << endl;
    }
    else if(number% 8==0)
    {
        cout <<"The number is not a prime number" << endl;
    }
    else if(number% 9==0)
    {
        cout <<"The number is not a prime number" << endl;
    }
    else
    {
        cout <<"The number is a prime number" << endl;
    }


    return 0;
}


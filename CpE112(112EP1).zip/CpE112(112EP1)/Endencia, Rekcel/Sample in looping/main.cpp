#include <iostream>

using namespace std;

//for loop
/*int main()
{
    int number;
    cout<< "Enter number 20  numbers..." << endl;

    for (int x = 1; x <= 20; x++)
        {
    cout << "Enter number : " << x << "\n";
    cin >> number;
        }

    for (int x = 1; x <= 3; ++x)
        {
    cout << " Enter number " << x << "\n";
    cin >> number;

        }
    return 0;

}*/

//while loop

/*int main()
{
    int number;
    int x = 1;
    while(x<=20)
    {
        cout <<"Enter number " << x << ":";
        cin >> number ;
        x++;
    }

    return 0;
}*/

//do while loop

/*int  main ()
{
    int number;

    int x=1;
    do
    {
        cout << "Enter number " << x << ":";
        cin >> number;
        x++;

    }while (x<=20);



    return 0;
}*/


int main()
{
    int number, remainder = 0 ;

    cout << "Prime Checker" << endl;
    cout << "Enter a number: ";
    cin >> number;

    for (int x = 2 ; x <= 9; x++)
    {
        if (number % x == 0)
        {
            remainder ++;
        }
    }

    if ((number == 2 || number == 3 || number == 1 || number == 5 || number == 7))
    {
        cout << "Prime number !!" << endl;
    }
    else if (remainder > 0)
    {
        cout << "Not a prime number !!" << endl;
    }
    else
    {
        cout << "Prime number" << endl;
    }



    return 0;
}





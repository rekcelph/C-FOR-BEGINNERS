#include <iostream>
using namespace std;

int main()
{
    char choice;
    int Num1, Num2;
    cout <<"Simple Calculator" <<endl;
    cout <<"Choose +, -, /, * ";
    cin >> choice;
    cout <<"Enter 1st number: ";
    cin >> Num1;
    cout <<"Enter 2nd number: ";
    cin >> Num2;

    if (choice == '+')
    {
    cout << "Sum of: " <<Num1 << " and " << Num2 << " is " << Num1 + Num2;
    }
    else if (choice == '-')
    {
    cout << "Difference of: " << Num1 << " and " << Num2 << " is " << Num1 - Num2;
    }
    else if (choice == '*')
    {
    cout << "Product of " << Num1 << " and " << Num2 << " is " << Num1 * Num2;
    }
    else if (choice == '/')
    {
    cout << "Quotient of: " << Num1 << " and " << Num2 << " is " << Num1 / Num2;
    }
    else
    {
        cout << "choices invalid";
    }
    return 0;
}

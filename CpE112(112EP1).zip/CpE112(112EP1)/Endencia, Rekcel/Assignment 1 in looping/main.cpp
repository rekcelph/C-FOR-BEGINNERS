#include <iostream>

using namespace std;

int main()
{
    int total = 0;
    int num;

    for (int x = 0; x < 10; x++)
{

        cout << "Enter a number " << x + 1 << " : ";
        cin >> num;
        total = total + num;
}


    cout << "The sum of the 10 numbers is: " << total << endl;

    return 0;
}

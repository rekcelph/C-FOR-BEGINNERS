#include <iostream>

using namespace std;

int main()
{
    int Angle_A, Angle_B, Angle_C;

    cout << "The program will determine if the triangle is Scalene, Isosceles, or Equilateral.." << endl;
    cout << "Enter 3 Triangle.." << endl;
    cout << "Enter Angle A: ";
    cin >> Angle_A;
    cout << "Enter Angle B: ";
    cin >> Angle_B;
    cout << "Enter Angle C: ";
    cin >> Angle_C;


    if ((Angle_A == 0) || (Angle_B == 0) || (Angle_C == 0) )
    {
        cout << "This is not a Triangle.." << endl;
    }
    else if (Angle_A + Angle_B + Angle_C != 180)
    {
        cout << "This is not a Triangle" << endl;
    }
    else if (Angle_A == Angle_B && Angle_B == Angle_C)
    {
         cout << "It's an Equilateral triangle." << endl;
    }
    else if (Angle_A != Angle_B && Angle_B != Angle_C && Angle_A != Angle_C)
    {
        cout << "The triangle is a Scalene" << endl;
    }
    else
    {
        cout << "The triangle is an Isosceles Triangle.." << endl;
    }


    return 0;
}

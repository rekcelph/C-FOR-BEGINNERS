#include <iostream>
/*While loop*/

using namespace std;

#include <iostream>
using namespace std;

int main() 
{
    char choice = 'y' ;


    while (choice == 'y' || choice == 'Y') {
        int num;
        cout << "Enter a number: ";
        cin >> num;

        int Prime = 0;
        if (!(cin >> num))
        {
            cout << "Please Enter numbers only..." << endl;
            break;
        }
        else if (num <= 0) 
        {
            Prime = 0;
        }
        else if (num == 2) 
        {
            Prime = 1;
        }
        else if (num % 2 == 0) 
        {
            Prime = 0;
        }
        else 
        {
            for (int x = 3; x * x <= num; x += 2) 
            {
                if (num % x == 0) 
                {
                    Prime = 0;
                    break;
                }
            }
        }

        if (Prime) {
            cout << "The number is a prime number" << endl;
        }
        else {
            cout << "The number is not a prime number" << endl;
        }

        cout << "Do you want to try another number? (y/n): ";
        cin >> choice;
    }

    return 0;
}

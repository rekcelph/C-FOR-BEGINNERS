#include <iostream>
/*Do While loop*/

using namespace std;

int main()

{
    char choice;
    
    do
    {
        int n;
        int f = 1;
        cout << " Enter a Number : " ;
        if (!(cin >> n))
        {
            cout << "Please Enter numbers only..." << endl;
        }
        else
        {
            for (int x = 1; x <= n ; x++)
            {
                 f = f*x;
            }
            cout << "The Factorial of : " << n << " is " << f << endl;
        }
        
        cout << "Try again?? (y/n): ";
        cin >> choice;
        

    } while (choice == 'y' || choice == 'Y');


    return 0;
    
    
}











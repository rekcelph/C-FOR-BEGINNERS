#include<iostream>
using namespace std;
/*Do While loop*/

int main() 
{
    int n;
    cout << "Enter a number : ";
    cin >> n;

    int x = 1;
    int sum = 0;
    do {
        sum += x * x;
        x++;
    } while(x <= n);

    cout << "The sum of the series is: " << sum << endl;

    return 0;
}

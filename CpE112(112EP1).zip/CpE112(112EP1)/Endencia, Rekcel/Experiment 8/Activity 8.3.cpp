#include <iostream>
/*While loop*/

using namespace std;

int main()

{
    cout << "The program will determine the GCF of the two numbers" << endl;
    char choice;
    while (choice == 'y' || choice == 'Y' );{
    int num1, num2;

    cout << "Enter 1st number :";
    cin >> num1;
    cout << "Enter 2nd number :";
    cin >> num2;

    int gcf;
    for (int x = 1; x<=num1 && x<=num2 ; x++)
    {
        if (num1 % x==0 && num2 % x == 0)
        {
            gcf=x;
        }
    }
    cout << " GCf of " << num1 << " and " << num2 << " is " << gcf << endl;
    cout << " Wanna enter an another number?? (y/n) " << endl;
    cin >> choice;
    cout << " Edi don't" << endl;
    cin >> choice;
     
    }
   
   return 0;

   
}


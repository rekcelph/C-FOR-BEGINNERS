#include <iostream>

using namespace std;

int main()
{
    int number;
    cout<<"Enter a number:";
    cin >> number;
    if (number > 5)
    {
        cout<< "The number is greater than  5" <<endl;
    }
     else if (number <= 5)
    {
        cout<< "The number is less than 5" <<endl;
        number = number + 3;
    }
     else if (number == 5)
    {
        cout<< "The number is equal 5"<<endl;
    }
        cout<< "number is equal_"<<number;
    return 0;
}

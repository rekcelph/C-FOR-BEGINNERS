#include <ctime>
#include <cstdlib>
#include <iostream>
using namespace std;


/*Create a c++ program for a guessing game. The program will generate a random number from 1 to 100 and add a loop and if else */

/*guess 10 too low and 30 if too high*/

 int main()
        {
        
            cout << "Welcome to my first guessing game"<< endl;
            srand ((unsigned) time (0) );
            int choice, random = (rand () % 101 ) + 1 ;
            
            for ( int x = 0 ; x <= 100 ; x++)
            
           {
            
            cout << "enter your number : " << endl;
            cin >> choice;
            

                if (choice  < random )
                {
                    cout << "The number is too low " << endl;
                }
                else if (choice  > random)
                {
                    cout <<"The number is too high" << endl;
                }
                else 
                {
                    cout << "Congrats, you've guess the number" << endl;
                    cout << "Let's play again " << endl;
                    break;
                }
           } 
            


            
    

            
            
            return 0;
        }

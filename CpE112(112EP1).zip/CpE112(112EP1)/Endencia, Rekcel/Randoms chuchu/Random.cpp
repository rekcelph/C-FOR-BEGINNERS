/*Use to generate random values */
/*include in the cstdilb*/
/*This will produce a result in the range 0 to RAND_MAX
where RAND_MAX is a constant defined by the implementation.*/

/*Syntax: 
        
            int random_number = rand()
        |            |                |
        data      Variable name/        Random function
        type       Identifier                               */

        #include <ctime>
        #include <cstdlib>
        #include <iostream>
        using namespace std;

       /* int main()
        {
            int random_number = rand();
            
            cout << random_number << endl;

            return 0;

            
        }*/

        int main()
        {
            srand ((unsigned) time (0) );
            
            for ( int x = 1 ; x <= 10 ; x++)
            
            
            {
                int random = (rand () % 22 ) + 25 ;
                cout << random << endl;

            }
    

            
            
            return 0;
        }


    
        

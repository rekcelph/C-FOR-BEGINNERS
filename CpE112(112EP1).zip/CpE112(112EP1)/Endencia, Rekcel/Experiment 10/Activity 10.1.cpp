#include <iostream>
using namespace std;

int main() 
{
    char choice[30]; 
    cout << "Enter any word : ";
    cin.getline(choice, 30);

    cout << "Original : " << choice << endl;
    cout << "Reversed : ";

    int length = 0;
    while (choice [length] != 0) {
        length++;
    }

    for (int x = length - 1; x >= 0; x--) 
    {
        cout << choice[x];
    }

    cout << endl;

    return 0;
}

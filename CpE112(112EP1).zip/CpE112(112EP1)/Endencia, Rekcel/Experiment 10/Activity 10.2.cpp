/*#include <iostream>
include <algorithm>
using namespace std;

int main()
{
    
       
    int array[10];
    int even = 0;
    int odd = 0;

    cout <<"Please Enter 10 numbers " << endl;
    for (int x = 0; x < 10 ; x++)
    {
        cout << "number: ";
        cin >> array[x];
    }

     cout << "Here are the results : " << endl;
     
     for (int x = 0; x < 10 ; x++)
     {
        cout << " " << array[x] << " is";
        if (array[x]%2==0)
        {
            cout << " an even number " << endl;
            even++;
        }
        else
        {
            cout << " an odd number " << endl;
            odd++;
        }
     }

     cout << "Therefore the total number of the Even numbers is " << even << " and the total number of the Odd numbers is " << odd << "."<< endl;

     return 0;
}*/

/*// odd number ascending order
    for (int i = 0; i <= n; ++i)
    {
        for (int j = i + 1; j < n; ++j)
        {
            if (arr[i] < arr[j])
            {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    for (int i = 0; i < n; ++i)
    {
        if (arr[i] % 2 == 0)
        {
            cout << arr[i]<< " ";
        }
    }

// numbers in descending order
    for (int i = 0; i <= n - 1; i++)
    {
        for (int j = i + 1; j <= n; j++)
        {

            if (arr[j] < arr[i])
            {
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }
        if (arr[i] % 2 == 1)
        {
            cout << arr[i]<<" ";
        */

#include <iostream>
using namespace std;

int main()
{
    int array[10];
    int evenArray[10], oddArray[10];
    int even = 0, odd = 0;

    cout << "Please Enter 10 numbers " << endl;
    for (int x = 0; x < 10; x++)
    {
        cout << "number: ";
        cin >> array[x];
    }

    //To separate even and odd numbers
    for (int x = 0; x < 10; x++)
    {
        if (array[x] % 2 == 0)
        {
            evenArray[even] = array[x];
            even++;
        }
        else
        {
            oddArray[odd] = array[x];
            odd++;
        }
    }

    // for even
    for (int i = 0; i < even - 1; i++)
    {
        for (int j = 0; j < even - i - 1; j++)
        {
            if (evenArray[j] > evenArray[j + 1])
            {
                // for ascending chuchu
                int ascendeve = evenArray[j];
                evenArray[j] = evenArray[j + 1];
                evenArray[j + 1] = ascendeve;
            }
        }
    }

    // For odd
    for (int i = 0; i < odd - 1; i++)
    {
        for (int j = 0; j < odd - i - 1; j++)
        {
            if (oddArray[j] > oddArray[j + 1])
            {
                //  para sa ascending chuchu
                int ascendodd = oddArray[j];
                oddArray[j] = oddArray[j + 1];
                oddArray[j + 1] = ascendodd;
            }
        }
    }
    cout << "Here are the results : " << endl;

    cout << "Even numbers in ascending order: ";
    for (int i = 0; i < even; i++)
    {
        cout << evenArray[i] << " ";
    }
    cout << endl;

    cout << "Odd numbers in ascending order: ";
    for (int i = 0; i < odd; i++)
    {
        cout << oddArray[i] << " ";
    }
    cout << endl;

    cout << "Therefore, the total number of even numbers is " << even << " and the total number of odd numbers is " << odd << "." << endl;

    return 0;
}


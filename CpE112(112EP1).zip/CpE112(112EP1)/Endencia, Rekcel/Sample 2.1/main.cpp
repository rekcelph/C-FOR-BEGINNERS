#include <iostream>
using namespace std;
int main()
{

int Age = 20;
int Width = 150, Height = 430, Value = 79;
float Money = 9.5;
double pi = 3.1415926535;
cout << "He is " << Age << " years old" << endl;
cout << "The rectangle is " << Width << " by " << Height << " units \n";
cout << Value << " in decimal" << endl;
cout << Money << " data type should be a float" << endl;

return 0;
}

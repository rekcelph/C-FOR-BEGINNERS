#include <iostream>
#define PI 3.14159
using namespace std;

int main()
{
    double radius , base , height;
    double AreaOfCircle, AreaOfRec;
    cout<< "AreaOfCircle and Rectangle Calculator" <<endl;
    cout<<"Enter radius : ";
    cin>> radius;
    cout<< "Enter base : ";
    cin>> base;
    cout<< "Enter height : ";
    cin>> height;
    AreaOfCircle = PI * radius;
    AreaOfRec = base * height;
    cout<< "Area of Circle is " <<AreaOfCircle <<endl;
    cout<< "Area of Rectangle " <<AreaOfRec <<endl;

    return 0;


}



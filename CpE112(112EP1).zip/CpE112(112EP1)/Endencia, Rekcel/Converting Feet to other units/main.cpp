#include <iostream>
using namespace std;

int main()
{
    double feet;
    cout << "Enter length in feet: ";
    cin >> feet;
// Converting feet to other units

    double meters = feet * 0.3048;
    double inches = feet * 12;
    double centimeters = feet * 30.48;
    double yards = feet / 3;
    double miles = feet / 5280;

// Displaying the equivalent lengths

    cout << "Length in meters: " << meters << " m" << endl;
    cout << "Length in inches: " << inches << " inches" << endl;
    cout << "Length in centimeters: " << centimeters << " cm" << endl;
    cout << "Length in yards: " << yards << " yards" << endl;
    cout << "Length in miles: " << miles << " miles" << endl;


    return 0;
}

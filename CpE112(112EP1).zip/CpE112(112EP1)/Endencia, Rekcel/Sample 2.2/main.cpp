#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    float Money = 9.5;
    double PI = 3.1415926535;

    cout << fixed << setprecision(6) << "(default fixed) 6 decimal places: " << PI << endl;
    cout << fixed << setprecision(1) << "1 decimal place: " << Money << endl;
    cout << fixed << setprecision(2) << "2 decimal places: " << PI << endl;
    cout << fixed << setprecision(3) << "3 decimal places: " << Money << endl;
    cout << fixed << setprecision(4) << "4 decimal places: " << PI << endl;


    return 0;
}

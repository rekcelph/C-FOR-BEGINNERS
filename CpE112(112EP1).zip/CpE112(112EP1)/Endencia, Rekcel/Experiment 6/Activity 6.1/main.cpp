#include <iostream>
using namespace std;

int main()
{
    char choice;
    double temperature, converted_Temperature;

    cout << "Choose an option: \n";

    cout << " Convert from Fahrenheit to Celsius\n";

    cout << " Convert from Celsius to Fahrenheit\n";

    cout << "If you want to convert Fahrenheight to Celsius enter F " << endl;

    cout << "If you want to convert Celsius to Farenheight enter C " << endl;

    cout << "Please select your choice : " ;

    cin >> choice;

    switch (choice)
    {
        case 'F':
            cout << "Enter temperature in Fahrenheit: ";

            cin >> temperature;

            converted_Temperature = (temperature  - 32) * 5/9;

            cout << "Temperature in Celsius: " << converted_Temperature << " degrees Celsius" << endl;
            break;

        case 'C':
            cout << "Enter temperature in Celsius: ";

            cin >> temperature;

            converted_Temperature =  9/5 * (temperature + 32);

            cout << "Temperature in Fahrenheit: " << converted_Temperature << " degrees Farenheight" << endl;
            break;

        default:

            cout << "\nKindly please enter C or F first" << endl;
            cout << "\nBefore you enter the amount of Celsius or Farenheight" << endl;
            break;
    }

    return 0;
}

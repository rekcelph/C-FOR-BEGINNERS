#include <iostream>
using namespace std;

int main()
{
    int B = 200, F = 50, P = 500, S = 150;
    int total_price = 0;
    cout << "Welcome to Aki Burger and Everything" << endl;
    cout << "We offer Burger (B), French Fries (F), Pizza (P), and Sandwiches (S)" << endl;
    cout << " Burger Php 200," << " French Fries Php 50, "  << " Pizza 500 Php, " << " Sanwiches " << endl;
    char choice;
    do
    {
        cout << "Enter your choice (B/F/P/S): ";
        cin >> choice;
        int numItems;
        switch (choice)
        {
        case 'B':
        case 'b':
            cout << "How many Burgers do you want to order? ";
            cin >> numItems;
            total_price += numItems * B;
            cout << " Your total amount : " << total_price;
            break;

        case 'F':
        case 'f':
            cout << "How many French Fries do you want to order? ";
            cin >> numItems;
            total_price += numItems * F;
            cout << " Your total amount : " << total_price;
            break;

        case 'P':
        case 'p':
            cout << "How many Pizzas do you want to order? ";
            cin >> numItems;
            total_price += numItems * P;
            cout << " Your total amount : " << total_price;
            break;

        case 'S':
        case 's':
            cout << "How many Sandwiches do you want to order? ";
            cin >> numItems;
            total_price += numItems * S;
            cout << "Your total amount : " << total_price;
            break;

        default:
            cout << "Invalid choice. Please enter B, F, P, or S." << endl;
            break;
        }

        cout << " Do you still want to order more? (Y/N): ";
        cin >> choice;
    } while (choice == 'Y' || choice == 'y');

    cout << " Your total price is : Php " << total_price << endl;

    return 0;
}

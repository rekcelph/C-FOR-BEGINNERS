#include <iostream>

using namespace std;


/*void myFunction() {
  cout << "I just got executed!";
}

int main() {
  myFunction(); // call the function
  return 0;
}

// Outputs "I just got executed!"*/


int Add (int x, int y)
{
    int sum = x + y;
    return sum;
}
int main()
{
    int num1 = 10, num2= 5;
    int sum;
    
    sum = Add (num1, num2);
    
    cout << "Sum is " << sum <<  endl;

    return 0;
}



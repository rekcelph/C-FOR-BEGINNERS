#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    char pressed;

    cout <<"Press any character" << endl;

    pressed = getch();
    
    if (pressed == 'a' || pressed == 'e' || pressed =='i'|| pressed == 'o'|| pressed == 'u')
    {
        cout << "You passed a vowel" << endl;

    }
    else
    {
        cout << "\nit is not a vowel" << endl;
    }

    return 0;


}
#include <iostream>

using namespace std;

int main()
{
    cout << "\n\nWestern Institute of Technology" << endl;
    cout << "Programming in Code Blocks C ++" << endl;
    cout << "Console Application" << endl;
    cout << "\n\nRekcel M. Endencia" << endl;
    cout << "Computer Engineer" << endl;
    cout << "\nHi self how are you doing?" <<endl;
    cout << "I hope you're doing well at home and at school." <<endl;
    cout << "I'd be happy to see you smiling today," <<endl;
    cout << "since I rarely saw you smile and talk." <<endl;
    cout << "Are you just lazy or is there something bothering you?" << endl;
    cout << "\nYou're probably just enjoying the things you do just like" << endl;
    cout << "playing your acoustic guitar,drawing,and play the games you love most." << endl;
    cout << "You have been through a lot since childhood." << endl;
    cout << "Yet, I am happy to see you alive and free." << endl;
    cout << "You may have lost some of your friends." << endl;
    cout << "But that's just how life is.\n\n" << endl;



    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    cout <<"\t\t\tA SONG ABOUT LIFE\n"<<endl;
    cout <<"\t\tLife is all the simple things"<<endl;
    cout <<"\t\t\tThat we do and say."<<endl;
    cout <<"\t\tAnd the much bigger things"<<endl;
    cout <<"\t\t\tThat come into play.\n"<<endl;
    cout <<"\t\tLife is joy and sorrow"<<endl;
    cout <<"\t\t\tAs we go along."<<endl;
    cout <<"\t\tThe smile and the tear"<<endl;
    cout <<"\t\tThe happy and the sad song."<<endl;
    cout <<"\t\t\tWritten by: Walterrean Salley"<<endl;

    return 0;
}

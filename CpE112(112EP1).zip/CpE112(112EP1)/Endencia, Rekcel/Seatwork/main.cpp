#include <iostream>

using namespace std;

int main()
{
      int number;
    cout<<"Enter a number:";
    cin >> number;
    if (number% 2==1)
    {
        cout << "The number is an odd number" << endl;

    }
    else
    {
        cout<< "The number is an even number"<< endl;
    }


    return 0;
}



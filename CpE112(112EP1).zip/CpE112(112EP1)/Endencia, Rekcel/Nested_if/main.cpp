#include <iostream>
using namespace std;
#define MAGIC_NUMBER 26
int main()
{
    int Value;
    cout <<"Enter a number between 10 to 100: ";
    cin >> Value;
    if(Value == MAGIC_NUMBER)
    {
    cout <<"Congratulations! You guessed the magic number!\n\n";
    }
    else if((Value > 10)&&(Value < 100))
    {
    if(Value > MAGIC_NUMBER)
    {
    cout << "Too high!!!\n\n";
    }
    else
    {
    cout << "Too low!!!\n\n";
    }
    }
    else
    {
    cout << "INVALID ENTRY!!!";
    }
return 0;
}

#include <iostream>

using namespace std;

int main()
{
    cout<< "Law ay \nsi \nRekcel";
    return 0;

}



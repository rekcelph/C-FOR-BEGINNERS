#include <iostream>
#include <iomanip> 

using namespace std;

int main() {
    int square_side = 15;
    double rectangle_length = 10;
    int rectangle_width = 8;
    int radius = 15;
    double number_1 = 15.557;
    int number_2 = 20;
    int number_3 = 25;
    double Money = 9.50;
    double PI = 3.1415926535;
    int squareArea = 50;
    float rec_Area;
    double cir_Area;

    cir_Area = PI * radius * radius;
    squareArea = square_side * square_side;
    rec_Area = rectangle_length * rectangle_width;

    cout << "The first number is " << number_1 << endl;
    cout << "The second number is " << number_2 << endl;
    cout << "Area of square is " << squareArea << endl;
    cout << "Area of rectangle is " << rec_Area << endl;
    cout << "Area of circle is " << fixed << setprecision(3) << cir_Area << endl;
    cout << "Area of circle is " << fixed << setprecision(4) << cir_Area << endl;
    cout << "Area of circle is " << fixed << setprecision(5) << cir_Area << endl;

    return 0;
}

#include <iostream>
using namespace std;

int main() {
    char choice;
    double num1, num2, answer;

    cout << "Enter an operator (+, -, *, /): ";
    cin >> choice;

    cout << "Enter 1st number: ";
    cin >> num1;
    cout << "Enter 2nd number";
    cin >> num2;

    switch (choice) {
        case '+':
            answer = num1 + num2;
            cout << "Answer = " << answer << endl;
            break;

        case '-':
            answer = num1 - num2;
            cout << "Answer = " << answer << endl;
            break;

        case '*':
            answer = num1 * num2;
            cout << "Answer = " << answer << endl;
            break;

        case '/':
            if (num2 != 0) {
                answer = num1 / num2;
                cout << "Answer = " << answer << endl;
            } else {
                cout << "Error: Division by zero." << endl;
            }
            break;

        default:
            cout << "Invalid choice" << endl;
            break;
    }

    return 0;
}

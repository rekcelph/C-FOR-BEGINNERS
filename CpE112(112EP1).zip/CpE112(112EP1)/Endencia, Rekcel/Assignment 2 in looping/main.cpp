#include <iostream>

using namespace std;

int main()
{
    int num;
    cout << "Enter a number : " << endl;
    cin >> num;
    cout << "Even numbers within 1 " << num << " are : ";

    for (int x = 1; x <= num; x++)
{
    if (x % 2 == 0)
{
    cout << x << " ";
}
}
    cout << endl;

    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    int number_1, number_2;
    cout<<"The program will determine if the lower number will subtract from a higher number" << endl;
    cout <<"Enter 1st number:" << endl;
    cin>> number_1;
    cout <<"Enter 2nd number" <<  endl;
    cin>> number_2;

    if  (number_1 > number_2)
    {
        cout << " The difference of " << number_1 << " and " << number_2 << " is " << number_1 - number_2;
    }
    else
    {
        cout <<" The difference of " << number_2 << " and " << number_1 << " is " << number_2 - number_2;
    }


    return 0;
}

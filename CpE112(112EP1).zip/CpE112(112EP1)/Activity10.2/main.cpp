#include <iostream>

using namespace std;

int main()
{
    int nums[10];
    int evenCount=0;
    int oddCount=0;

    for (int x=0;x<10;x++)
    {
        cout << " Enter number " << (x+1) << " : ";
        cin >> nums [x];
    }
    for (int x=0;x<10;x++)
    {
        if (nums[x]%2==0)
        {
            evenCount++;
        }
        else
        {
            oddCount++;
        }
    }
    cout << "\nEven numbers: ";

    for (int x=0;x<10;x++)
    {
        if (nums[x]% 2==0)
        {
            cout << nums[x]<< " ";
        }
    }

    cout << " \nOdd numbers: ";
    for (int x=0;x<10;x++)
    {
        if (nums[x]%2!=0)
        {
            cout << nums [x]<<" ";
        }
    }
    cout << endl;
    return 0;
}

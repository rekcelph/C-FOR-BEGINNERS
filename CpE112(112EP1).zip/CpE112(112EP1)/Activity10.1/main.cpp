#include <iostream>
#include <cstring>
using namespace std;

 void reverseString(char*str)
{
    int len=strlen(str);
    for (int x=0;x<len/2;x++)
        {
        swap (str[x],str[len-x-1]);
        }
}

int main()
{
    char word [31];
    cout << " Enter a word up to 30 characters: ";
    cin.getline(word,31);

    reverseString (word);
    cout << " Reversed word: "<< word << endl;
    return 0;
}
